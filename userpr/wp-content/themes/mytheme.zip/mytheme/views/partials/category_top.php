<!-- Categories -->
<!--Vertical Tab-->

<div class="categories-section main-grid-border">
    <div class="container">
        <h2 id="item_select_page_header" class="head">دسته های اصلی</h2>
        <div class="category-list">
            <div id="parentVerticalTab">




