<div id="myTabContent1" >
    <?php
    comments_template(null,true);
    ?>
</div>
