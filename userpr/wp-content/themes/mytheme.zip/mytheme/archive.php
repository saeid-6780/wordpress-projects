<?php
get_header();
get_template_part('views/partials/header');
get_template_part('views/partials/banner_top');
get_template_part('views/partials/category_top');
get_template_part('views/partials/category_sidbar');
get_template_part('views/partials/category_item_list');
get_template_part('views/partials/category_close');

get_footer();
?>