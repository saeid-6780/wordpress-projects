<?php
get_header();
get_template_part('views/partials/header');
//get_template_part('views/partials/basket');
get_template_part('views/partials/banner_top');
get_template_part('views/partials/main_category');
get_footer();
?>


