<?php
define('THEME_PATH',get_template_directory());
define('THEME_URL',get_template_directory_uri());
define('THEME_OPTIONS','mytheme_options');
?>