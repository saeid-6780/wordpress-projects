<div class="copy-section">
    <div class="container">
        <div class="copy-right">
            <p>&copy; 1397 گردآوری داده ماوس | طراحی توسط <a href="#">سعید صدیق زاده</a></p>
        </div>
        <div class="copy-left">
            <img src="<?= theme_asset::image('ui.png') ?>" alt=""/>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

</div>
<?php

wp_footer();
?>

</body>
</html>